# 📡 PhoneOSINT — Phone Number OSINT Recon Tool

> Built for SOC Analyst learning | Ethical & Legal Use Only

---

## 🚀 Quick Start

```bash
# Basic scan
python3 phoneosint.py -n +919876543210

# With Numverify API key (free at numverify.com)
python3 phoneosint.py -n +919876543210 --api-key YOUR_KEY

# Save report to file
python3 phoneosint.py -n +919876543210 -o my_report

# Skip certain modules
python3 phoneosint.py -n +919876543210 --skip-dorks --skip-breach
```

---

## 📦 Optional Dependencies

```bash
# Install for richer number validation (carrier, timezone, type)
pip install phonenumbers

# Install for automated Google dorking
pip install googlesearch-python

# Install for email → platform checks
pip install holehe
```

Without these, the tool still works using built-in Python only.

---

## 🧩 Modules

| # | Module | What It Does |
|---|--------|-------------|
| 1 | Number Validation | Country, carrier, type, region, E164 format |
| 2 | Google Dorks | 16 ready-to-use dork queries + clickable Google links |
| 3 | Social Media | LinkedIn, Facebook, Instagram, Twitter, Truecaller links |
| 4 | Reputation Check | Spam/scam database lookups |
| 5 | Job/Business | LinkedIn, JustDial, IndiaMart, MCA India directories |
| 6 | Breach Check | HaveIBeenPwned, IntelX, DeHashed, Pastebin |
| 7 | Numverify API | Carrier + line type via API (optional key) |
| 8 | WhatsApp Check | Clickable wa.me presence check link |
| 9 | Report Export | JSON + TXT report auto-saved |

---

## ⚠️ Legal Notice

- Use only on your own number or with **written consent**
- Authorized for: CTF, threat intel, bug bounty, SOC investigations
- India: IT Act 2000 applies — unauthorized use is illegal

---

## 🛣️ Upgrade Ideas (For Your Portfolio)

- [ ] Add `holehe` integration (email lookup from number)
- [ ] Add Shodan API for VOIP/IP correlation
- [ ] Add Telegram bot API check
- [ ] Add HTML report with styled output
- [ ] Add proxy/Tor routing support
- [ ] Convert to async for faster parallel scanning
- [ ] Add Maltego transform compatibility
