#!/usr/bin/env python3
"""
PhoneOSINT - Open Source Intelligence Tool for Phone Numbers
Author: Built for SOC Analyst learning purposes
Usage: python3 phoneosint.py -n +91XXXXXXXXXX
WARNING: Use only on your own number or with explicit consent.
"""

import argparse
import json
import sys
import time
import urllib.parse
import urllib.request
import re
from datetime import datetime

# ─── Color codes for terminal output ───────────────────────────────────────────
class Colors:
    RED     = "\033[91m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    BLUE    = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN    = "\033[96m"
    WHITE   = "\033[97m"
    BOLD    = "\033[1m"
    RESET   = "\033[0m"

def c(color, text):
    return f"{color}{text}{Colors.RESET}"

# ─── Banner ────────────────────────────────────────────────────────────────────
def banner():
    print(c(Colors.CYAN, Colors.BOLD + """
╔═══════════════════════════════════════════════════════╗
║           PhoneOSINT - OSINT Recon Tool               ║
║        For authorized investigations only             ║
║   SOC Analyst Learning Tool | Ethical Use Only        ║
╚═══════════════════════════════════════════════════════╝
"""))

# ─── Section printer ───────────────────────────────────────────────────────────
def section(title):
    print(c(Colors.YELLOW, f"\n{'═'*55}"))
    print(c(Colors.YELLOW, f"  ▶  {title}"))
    print(c(Colors.YELLOW, f"{'═'*55}"))

def info(label, value):
    print(f"  {c(Colors.CYAN, label+':'): <35} {c(Colors.WHITE, str(value))}")

def found(msg):
    print(c(Colors.GREEN,  f"  [+] {msg}"))

def warn(msg):
    print(c(Colors.YELLOW, f"  [!] {msg}"))

def fail(msg):
    print(c(Colors.RED,    f"  [-] {msg}"))

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 1 — NUMBER VALIDATION (uses phonenumbers library if installed,
#            otherwise falls back to pure regex + known country code mapping)
# ══════════════════════════════════════════════════════════════════════════════
COUNTRY_CODES = {
    "1":"United States/Canada","7":"Russia","20":"Egypt","27":"South Africa",
    "30":"Greece","31":"Netherlands","32":"Belgium","33":"France","34":"Spain",
    "36":"Hungary","39":"Italy","40":"Romania","41":"Switzerland","43":"Austria",
    "44":"United Kingdom","45":"Denmark","46":"Sweden","47":"Norway","48":"Poland",
    "49":"Germany","51":"Peru","52":"Mexico","53":"Cuba","54":"Argentina",
    "55":"Brazil","56":"Chile","57":"Colombia","58":"Venezuela","60":"Malaysia",
    "61":"Australia","62":"Indonesia","63":"Philippines","64":"New Zealand",
    "65":"Singapore","66":"Thailand","81":"Japan","82":"South Korea","84":"Vietnam",
    "86":"China","90":"Turkey","91":"India","92":"Pakistan","93":"Afghanistan",
    "94":"Sri Lanka","95":"Myanmar","98":"Iran","212":"Morocco","213":"Algeria",
    "216":"Tunisia","218":"Libya","220":"Gambia","221":"Senegal","234":"Nigeria",
    "254":"Kenya","255":"Tanzania","256":"Uganda","260":"Zambia","263":"Zimbabwe",
    "351":"Portugal","352":"Luxembourg","353":"Ireland","354":"Iceland","355":"Albania",
    "356":"Malta","357":"Cyprus","358":"Finland","359":"Bulgaria","370":"Lithuania",
    "371":"Latvia","372":"Estonia","380":"Ukraine","381":"Serbia","385":"Croatia",
    "386":"Slovenia","420":"Czech Republic","421":"Slovakia","852":"Hong Kong",
    "853":"Macau","855":"Cambodia","856":"Laos","880":"Bangladesh","886":"Taiwan",
    "960":"Maldives","961":"Lebanon","962":"Jordan","963":"Syria","964":"Iraq",
    "965":"Kuwait","966":"Saudi Arabia","967":"Yemen","968":"Oman","971":"UAE",
    "972":"Israel","973":"Bahrain","974":"Qatar","975":"Bhutan","976":"Mongolia",
    "977":"Nepal","992":"Tajikistan","993":"Turkmenistan","994":"Azerbaijan",
    "995":"Georgia","996":"Kyrgyzstan","998":"Uzbekistan",
}

def detect_country(number_digits):
    """Try to match country code (longest match first)."""
    for length in [3, 2, 1]:
        code = number_digits[:length]
        if code in COUNTRY_CODES:
            return code, COUNTRY_CODES[code]
    return "?", "Unknown"

def validate_number(raw_number):
    section("MODULE 1 — NUMBER VALIDATION & BASIC INFO")
    result = {}

    # Normalize
    cleaned = re.sub(r"[\s\-\(\)\.]+", "", raw_number)
    if cleaned.startswith("+"):
        digits = cleaned[1:]
    elif cleaned.startswith("00"):
        digits = cleaned[2:]
    else:
        digits = cleaned

    result["raw"]     = raw_number
    result["cleaned"] = "+" + digits
    result["digits"]  = digits
    result["length"]  = len(digits)

    country_code, country_name = detect_country(digits)
    result["country_code"] = country_code
    result["country"]      = country_name

    national = digits[len(country_code):]
    result["national_number"] = national

    # Try phonenumbers library for richer info
    try:
        import phonenumbers
        from phonenumbers import geocoder, carrier, timezone
        parsed = phonenumbers.parse(raw_number, None)
        result["valid"]       = phonenumbers.is_valid_number(parsed)
        result["possible"]    = phonenumbers.is_possible_number(parsed)
        result["region"]      = geocoder.description_for_number(parsed, "en")
        result["carrier"]     = carrier.name_for_number(parsed, "en") or "N/A"
        result["timezones"]   = list(timezone.time_zones_for_number(parsed))
        nt = phonenumbers.number_type(parsed)
        type_map = {
            0:"Fixed line", 1:"Mobile", 2:"Fixed or Mobile",
            3:"Toll free", 4:"Premium rate", 6:"VOIP", 7:"Personal number", 27:"Unknown"
        }
        result["number_type"] = type_map.get(nt, "Unknown")
        result["e164"]        = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164)
        result["intl_format"] = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
        result["lib"]         = "phonenumbers"
    except ImportError:
        result["valid"]       = len(digits) >= 7 and len(digits) <= 15
        result["region"]      = "N/A (install phonenumbers for detail)"
        result["carrier"]     = "N/A"
        result["timezones"]   = ["N/A"]
        result["number_type"] = "N/A"
        result["e164"]        = "+" + digits
        result["intl_format"] = "+" + digits
        result["lib"]         = "regex fallback"
    except Exception as e:
        result["parse_error"] = str(e)

    # Print
    info("Raw Input",        result["raw"])
    info("Normalized (E164)",result.get("e164", result["cleaned"]))
    info("Country Code",     f"+{result['country_code']}")
    info("Country",          result["country"])
    info("National Number",  result["national_number"])
    info("Region/State",     result.get("region", "N/A"))
    info("Carrier",          result.get("carrier", "N/A"))
    info("Number Type",      result.get("number_type", "N/A"))
    info("Valid",            "✅ Yes" if result.get("valid") else "❌ No")
    info("Timezones",        ", ".join(result.get("timezones", [])))
    info("Library Used",     result.get("lib", "N/A"))

    return result

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 2 — GOOGLE DORK QUERIES (generated for manual use)
# ══════════════════════════════════════════════════════════════════════════════
def google_dorks(number_info):
    section("MODULE 2 — GOOGLE DORK QUERIES")
    warn("Copy-paste these into Google manually or use googlesearch-python lib")

    num     = number_info.get("national_number", "")
    fullnum = number_info.get("e164", "")
    nat_fmt = num  # bare national digits

    dorks = [
        f'"{nat_fmt}"',
        f'"{fullnum}"',
        f'"{nat_fmt}" site:linkedin.com',
        f'"{nat_fmt}" site:facebook.com',
        f'"{nat_fmt}" site:instagram.com',
        f'"{nat_fmt}" site:twitter.com',
        f'"{nat_fmt}" site:truecaller.com',
        f'"{nat_fmt}" "@gmail.com"',
        f'"{nat_fmt}" "@yahoo.com"',
        f'"{nat_fmt}" site:pastebin.com',
        f'"{nat_fmt}" site:github.com',
        f'"{nat_fmt}" site:justdial.com',
        f'"{nat_fmt}" site:indiamart.com',
        f'"{nat_fmt}" "WhatsApp"',
        f'"{nat_fmt}" "contact" OR "email" OR "mail"',
        f'"{fullnum}" filetype:pdf',
        f'"{fullnum}" filetype:xls OR filetype:xlsx',
    ]

    google_links = []
    for i, dork in enumerate(dorks, 1):
        encoded = urllib.parse.quote(dork)
        url = f"https://www.google.com/search?q={encoded}"
        print(f"  {c(Colors.MAGENTA, str(i).zfill(2))}. {c(Colors.WHITE, dork)}")
        print(f"      {c(Colors.BLUE, url)}\n")
        google_links.append({"dork": dork, "url": url})

    return google_links

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 3 — SOCIAL MEDIA CHECKS (public lookup links)
# ══════════════════════════════════════════════════════════════════════════════
def social_media_check(number_info):
    section("MODULE 3 — SOCIAL MEDIA & PLATFORM LOOKUP LINKS")
    warn("Open these URLs manually — they show public profile pages if number is registered")

    num     = number_info.get("national_number", "")
    fullnum = number_info.get("e164", "").replace("+", "")
    country = number_info.get("country_code", "91")

    platforms = {
        "Truecaller"   : f"https://www.truecaller.com/search/in/{num}",
        "WhatsApp"     : f"https://wa.me/{fullnum}",
        "Telegram"     : f"https://t.me/+{fullnum}",
        "LinkedIn Search": f"https://www.linkedin.com/search/results/people/?keywords={num}",
        "Facebook"     : f"https://www.facebook.com/search/top?q={num}",
        "Twitter/X"    : f"https://twitter.com/search?q={num}",
        "Instagram"    : f"https://www.instagram.com/explore/tags/{num}/",
        "Google+"      : f"https://www.google.com/search?q=site:plus.google.com+{num}",
        "Skype"        : f"https://www.skype.com/en/",
        "Viber"        : f"https://chats.viber.com/{fullnum}",
        "Sync.me"      : f"https://sync.me/search/?number={fullnum}",
        "NumLookup"    : f"https://www.numlookup.com/?number=%2B{fullnum}",
        "SpyDialer"    : f"https://www.spydialer.com/default.aspx",
        "CallerID Test": f"https://calleridtest.com/",
    }

    results = {}
    for platform, url in platforms.items():
        print(f"  {c(Colors.GREEN, '→')} {c(Colors.CYAN, platform):<20} {c(Colors.BLUE, url)}")
        results[platform] = url

    return results

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 4 — REPUTATION / SPAM CHECK
# ══════════════════════════════════════════════════════════════════════════════
def reputation_check(number_info):
    section("MODULE 4 — SPAM & REPUTATION DATABASES")
    warn("Open these links to check if the number is flagged as spam/scam")

    num     = number_info.get("national_number", "")
    fullnum = number_info.get("e164", "").replace("+", "")
    country = number_info.get("country_code", "91")

    databases = {
        "Should I Answer"  : f"https://www.shouldianswer.com/phone-number/{fullnum}",
        "WhoCalledMe"      : f"https://www.whocalledme.com/PhoneNumber/{num}",
        "800notes"         : f"https://800notes.com/Phone.aspx/{fullnum}",
        "CallerSmart"      : f"https://www.callersmart.com/phone/{num}",
        "Scam Numbers"     : f"https://scamnumbers.info/{num}",
        "AbuseIPDB equiv"  : f"https://www.numlookup.com/?number=%2B{fullnum}",
        "Tellows (India)"  : f"https://www.tellows.in/num/{num}",
        "NumInfo"          : f"https://numinfo.net/{country}/{num}",
        "PhoneValidator"   : f"https://www.phonevalidator.com/index.aspx",
        "TRAI DND Check"   : f"https://www.trai.gov.in/consumers/do-not-disturb",
    }

    for db, url in databases.items():
        print(f"  {c(Colors.RED, '⚠')}  {c(Colors.CYAN, db):<25} {c(Colors.BLUE, url)}")

    return databases

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 5 — JOB / BUSINESS PROFILE LOOKUP
# ══════════════════════════════════════════════════════════════════════════════
def job_business_check(number_info):
    section("MODULE 5 — JOB & BUSINESS DIRECTORY LOOKUP")
    warn("Check if the number appears in professional/business directories")

    num     = number_info.get("national_number", "")
    fullnum = number_info.get("e164", "").replace("+", "")

    directories = {
        "LinkedIn People"  : f"https://www.linkedin.com/search/results/people/?keywords={num}",
        "LinkedIn Company" : f"https://www.linkedin.com/search/results/companies/?keywords={num}",
        "JustDial"         : f"https://www.justdial.com/{num}",
        "IndiaMart"        : f"https://www.indiamart.com/search.mp?ss={num}",
        "Sulekha"          : f"https://www.sulekha.com/search/results?src=header&q={num}",
        "Zaubacorp"        : f"https://www.zaubacorp.com/company-search/{num}",
        "MCA India"        : f"https://www.mca.gov.in/content/mca/global/en/home.html",
        "Yellow Pages IN"  : f"https://www.yellowpages.in/search?q={num}",
        "Glassdoor"        : f"https://www.glassdoor.co.in/Search/results.htm?keyword={num}",
        "Naukri"           : f"https://www.naukri.com/jobsearch/advanced-job-search?searchText={num}",
    }

    for site, url in directories.items():
        print(f"  {c(Colors.MAGENTA, '💼')} {c(Colors.CYAN, site):<25} {c(Colors.BLUE, url)}")

    return directories

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 6 — DATA BREACH / LEAK CHECK
# ══════════════════════════════════════════════════════════════════════════════
def breach_check(number_info):
    section("MODULE 6 — DATA BREACH & LEAK CHECK")
    warn("Check if the number appeared in known data breaches or leaks")

    num     = number_info.get("national_number", "")
    fullnum = number_info.get("e164", "")

    resources = {
        "HaveIBeenPwned"   : f"https://haveibeenpwned.com/",
        "IntelX"           : f"https://intelx.io/?s={urllib.parse.quote(fullnum)}",
        "Leak-Lookup"      : f"https://leak-lookup.com/",
        "Pastebin Search"  : f"https://pastebin.com/search?q={num}",
        "GhostProject"     : f"https://ghostproject.fr/",
        "DeHashed"         : f"https://www.dehashed.com/search?query={fullnum}",
        "Snusbase"         : f"https://snusbase.com/",
        "BreachDirectory"  : f"https://breachdirectory.org/",
    }

    for site, url in resources.items():
        print(f"  {c(Colors.RED, '🔓')} {c(Colors.CYAN, site):<25} {c(Colors.BLUE, url)}")

    return resources

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 7 — NUMVERIFY API (free tier — optional)
# ══════════════════════════════════════════════════════════════════════════════
def numverify_check(number_info, api_key=None):
    section("MODULE 7 — NUMVERIFY API (carrier & line type)")

    if not api_key:
        warn("No API key provided. Get a free key at: https://numverify.com/")
        warn("Run with: --api-key YOUR_KEY to enable this module")
        info("Skipped", "Numverify API module")
        return {}

    num = number_info.get("national_number", "")
    cc  = number_info.get("country_code", "91")

    url = f"http://apilayer.net/api/validate?access_key={api_key}&number={num}&country_code={cc}&format=1"
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read().decode())

        if data.get("valid"):
            found("Numverify returned valid result")
            info("Number",        data.get("number"))
            info("Local Format",  data.get("local_format"))
            info("Intl Format",   data.get("international_format"))
            info("Country",       data.get("country_name"))
            info("Location",      data.get("location"))
            info("Carrier",       data.get("carrier"))
            info("Line Type",     data.get("line_type"))
        else:
            fail("Numverify: Number not valid or not found")

        return data
    except Exception as e:
        fail(f"Numverify API error: {e}")
        return {}

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 8 — WHATSAPP QUICK CHECK
# ══════════════════════════════════════════════════════════════════════════════
def whatsapp_check(number_info):
    section("MODULE 8 — WHATSAPP PRESENCE CHECK")
    fullnum = number_info.get("e164", "").replace("+", "")
    wa_url  = f"https://wa.me/{fullnum}"
    api_url = f"https://api.whatsapp.com/send?phone={fullnum}"

    info("WhatsApp Click-to-Chat", wa_url)
    info("WhatsApp API Link",      api_url)
    warn("Open the wa.me link — if it loads a chat page, the number is on WhatsApp")
    warn("If it shows 'Phone number shared via URL' page → number exists on WhatsApp")

    return {"wa_url": wa_url, "api_url": api_url}

# ══════════════════════════════════════════════════════════════════════════════
# MODULE 9 — REPORT EXPORT
# ══════════════════════════════════════════════════════════════════════════════
def export_report(all_data, output_file):
    section("MODULE 9 — REPORT EXPORT")
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    all_data["scan_time"] = timestamp

    # JSON export
    json_file = output_file.replace(".txt", ".json") if output_file.endswith(".txt") else output_file + ".json"
    with open(json_file, "w") as f:
        json.dump(all_data, f, indent=2, default=str)
    found(f"JSON report saved → {json_file}")

    # Text summary export
    txt_file = output_file if output_file.endswith(".txt") else output_file + ".txt"
    with open(txt_file, "w") as f:
        f.write(f"PhoneOSINT Report — {timestamp}\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"Target Number : {all_data.get('number_info', {}).get('e164', 'N/A')}\n")
        f.write(f"Country       : {all_data.get('number_info', {}).get('country', 'N/A')}\n")
        f.write(f"Carrier       : {all_data.get('number_info', {}).get('carrier', 'N/A')}\n")
        f.write(f"Region        : {all_data.get('number_info', {}).get('region', 'N/A')}\n")
        f.write(f"Valid         : {all_data.get('number_info', {}).get('valid', 'N/A')}\n\n")
        f.write("Google Dorks:\n")
        for d in all_data.get("dorks", []):
            f.write(f"  {d['dork']}\n")
            f.write(f"  {d['url']}\n\n")

    found(f"Text report saved  → {txt_file}")

# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════
def main():
    parser = argparse.ArgumentParser(
        description="PhoneOSINT — Full OSINT recon tool for phone numbers",
        epilog="Example: python3 phoneosint.py -n +919876543210 -o report"
    )
    parser.add_argument("-n", "--number",  required=True, help="Target phone number (e.g. +919876543210)")
    parser.add_argument("-o", "--output",  default="",    help="Output file base name (default: auto-named)")
    parser.add_argument("--api-key",       default=None,  help="Numverify API key (optional, free at numverify.com)")
    parser.add_argument("--skip-dorks",    action="store_true", help="Skip Google dork generation")
    parser.add_argument("--skip-social",   action="store_true", help="Skip social media module")
    parser.add_argument("--skip-breach",   action="store_true", help="Skip breach check module")
    args = parser.parse_args()

    banner()

    print(c(Colors.RED, Colors.BOLD + """
  ⚠️  LEGAL DISCLAIMER:
  Use this tool ONLY on your own number or with EXPLICIT WRITTEN CONSENT.
  Unauthorized use may violate IT Act 2000 (India) and other laws.
  This tool is for SOC/OSINT learning and authorized investigations ONLY.
"""))

    all_data = {"target": args.number}

    # Run modules
    number_info = validate_number(args.number)
    all_data["number_info"] = number_info

    if not args.skip_dorks:
        dorks = google_dorks(number_info)
        all_data["dorks"] = dorks

    if not args.skip_social:
        social  = social_media_check(number_info)
        job     = job_business_check(number_info)
        wa      = whatsapp_check(number_info)
        all_data["social_media"] = social
        all_data["job_business"] = job
        all_data["whatsapp"]     = wa

    rep = reputation_check(number_info)
    all_data["reputation"] = rep

    if not args.skip_breach:
        breach = breach_check(number_info)
        all_data["breach"] = breach

    numv = numverify_check(number_info, args.api_key)
    all_data["numverify"] = numv

    # Export
    output_base = args.output or f"phoneosint_{args.number.replace('+','').replace(' ','_')}"
    export_report(all_data, output_base)

    section("SCAN COMPLETE")
    found("All modules executed successfully")
    info("Target",    args.number)
    info("Scan Time", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    print(c(Colors.CYAN, "\n  Happy hunting — stay ethical, stay legal! 🔍\n"))

if __name__ == "__main__":
    main()
